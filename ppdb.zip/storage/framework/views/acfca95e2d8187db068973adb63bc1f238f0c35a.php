<?php $__env->startSection('content'); ?>
<div class="jumbotron">
  <?php if(session('mssg')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('mssg')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>
  <div class="container">
    <h1 class="display-3">Pendaftaran santri baru</h1>
    <p>Assalamu'alaikum, selamat datang di halaman pendaftaran santri baru albinaa tahun ajaran 2021-2022. Silahkan klik link dibawah untuk melanjutkan pendaftaran.</p>
    <p><a class="btn btn-primary btn-lg" href="/daftar/create" role="button">Daftar &raquo;</a></p>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\FSociety\Documents\laravelproject\ppdb\resources\views/welcome.blade.php ENDPATH**/ ?>