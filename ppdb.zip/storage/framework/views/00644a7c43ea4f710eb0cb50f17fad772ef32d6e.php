

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Form pendaftaran santri baru</h2>

    <div>
        <a href="/daftar"><button class="btn btn-primary btn">Lihat list pendaftar</button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\FSociety\Documents\laravelproject\ppdb\resources\views/daftar.blade.php ENDPATH**/ ?>