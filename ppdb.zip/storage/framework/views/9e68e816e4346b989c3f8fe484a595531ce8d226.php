

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card-deck mb-3 text-center">
        <div class="card mb-4 box-shadow">
            <div class="card-header">
                <h4 class="my-0 font-weight-normal">Detail calon santri baru</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title"><?php echo e($santri->nama); ?></h1>
                <div class="row">
                    <div class="col-sm-4 text-left">Alamat :</div>
                    <div class="col-sm-8 text-left"><?php echo e($santri->alamat); ?></div>
                    <div class="col-sm-4 text-left">tempat dan tanggal lahir :</div>
                    <div class="col-sm-8 text-left"><?php echo e($santri->tempat_lahir); ?>, <?php echo e($santri->tgl_lahir); ?></div>
                    <div class="col-sm-4 text-left">Asal sekolah :</div>
                    <div class="col-sm-8 text-left"><?php echo e($santri->asal_sekolah); ?></div>
                </div>
                <a href="/daftar"><button type="button" class="btn btn-lg btn-outline-primary">Kembali</button></a>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\FSociety\Documents\laravelproject\ppdb\resources\views/show.blade.php ENDPATH**/ ?>