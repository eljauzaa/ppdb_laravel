@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Form pendaftaran santri baru</h2>

    <div>
        <a href="/daftar"><button class="btn btn-primary btn">Lihat list pendaftar</button></a>
    </div>
</div>
@endsection